﻿import tkinter as tk
root=tk.Tk(); root.title('block-studio'); root.geometry('520x320')
tk.Label(root,text='block-studio',font=('Segoe UI',28,'bold')).pack(pady=30)
tk.Label(root,text='VShop demo installer package.',font=('Segoe UI',12)).pack()
tk.Button(root,text='Close',command=root.destroy).pack(pady=20)
root.mainloop()
